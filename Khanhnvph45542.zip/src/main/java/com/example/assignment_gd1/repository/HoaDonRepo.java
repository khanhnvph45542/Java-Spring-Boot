package com.example.assignment_gd1.repository;

import com.example.assignment_gd1.model.HoaDon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HoaDonRepo extends JpaRepository<HoaDon , Integer> {
}
