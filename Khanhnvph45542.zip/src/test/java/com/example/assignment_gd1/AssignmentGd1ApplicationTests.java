package com.example.assignment_gd1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentGd1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
